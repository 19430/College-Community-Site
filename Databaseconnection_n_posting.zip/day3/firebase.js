//import { initializeApp } from 'firebase/app';
import firebase from "firebase"


const firebaseConfig = {
    apiKey: "AIzaSyAxQurwnQP0j1ys1SjUDDYcaAh0lJN2lwA",
    authDomain: "myproject-a1ddf.firebaseapp.com",
    projectId: "myproject-a1ddf",
    storageBucket: "myproject-a1ddf.appspot.com",
    messagingSenderId: "850975020597",
    appId: "1:850975020597:web:5bf2c85e74b6f465a5037c"
};

const firebaseApp = firebase.initializeApp(firebaseConfig);

const db=firebaseApp.firestore();

//we want to use firestore authentication
const auth= firebase.auth();

export{ db ,auth}