import firebase from 'firebase';

const firebaseConfig = {
    apiKey: "AIzaSyC3AkSo8u_9a3ydszLmXuC9JxGbEqkKJ7Y",
    authDomain: "project-5c012.firebaseapp.com",
    projectId: "project-5c012",
    storageBucket: "project-5c012.appspot.com",
    messagingSenderId: "938849590435",
    appId: "1:938849590435:web:e3f874480877d6d125f316"
  };

const firebaseApp=firebase.initializeApp(firebaseConfig);
const db= firebaseApp.firestore();
const auth =firebase.auth();
const provider =  new firebase.auth.GoogleAuthProvider();
const storage = firebase.storage();

export { auth, provider, storage};
export default db;